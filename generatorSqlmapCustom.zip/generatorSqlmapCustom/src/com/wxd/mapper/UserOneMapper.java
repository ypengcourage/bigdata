package com.wxd.mapper;

import com.wxd.model.UserOne;
import com.wxd.model.UserOneExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserOneMapper {
    int countByExample(UserOneExample example);

    int deleteByExample(UserOneExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(UserOne record);

    int insertSelective(UserOne record);

    List<UserOne> selectByExample(UserOneExample example);

    UserOne selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") UserOne record, @Param("example") UserOneExample example);

    int updateByExample(@Param("record") UserOne record, @Param("example") UserOneExample example);

    int updateByPrimaryKeySelective(UserOne record);

    int updateByPrimaryKey(UserOne record);
}